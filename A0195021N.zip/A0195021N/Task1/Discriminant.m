function [Alpha_dis,b0] = Discriminant(norm_tr_dt,train_label,ker_type,p,C)

% This function calculates the disciminant function g(x)'s for all types of 
% SVM. 

% ######## Input Args ########
% norm_tr_dt = normalized training data
% train_label = training label
% ker_type = (kernel type) i.e. Linhard or polyhard or polysoft
%   'linhard'         Linear Kernel x1'*x2
%   'polyhard'        Polynomial Kernel with Hard Margin (1+x1'*x2)^p
%   'polysoft'        Polynomial Kernel with Soft Margin (1+x1'*x2)^p
% p = degree of polynomial kernel
% C = cost of violating error
% #############################

% ######## Output Args ########
% Alpha_dis = alpha multiplied to train_label
% b0 = bias
% #############################



switch ker_type
    case 'linhard'
        kernel_mat = norm_tr_dt'*norm_tr_dt; 
        
    case 'polyhard'
        kernel_mat  = (ones(size(norm_tr_dt,2),size(norm_tr_dt,2)) + ...
            norm_tr_dt'*norm_tr_dt).^p;
      
    case 'polysoft'
        kernel_mat = (ones(size(norm_tr_dt,2),size(norm_tr_dt,2)) + ...
            norm_tr_dt'*norm_tr_dt).^p;
end

% check mercer's condition.
pos_def = eig(kernel_mat);
pos_def(abs(pos_def) < 1e-4) = 0;

if size(pos_def(pos_def < 0),1) ~= 0
     disp('Mercer''s condition failed!');
     return
end

H = (train_label*train_label').*kernel_mat;

%H = H + 0.0000001*eye(size(H));

f = -1.*ones(size(train_label,1),1); 
A = -eye(size(train_label,1));
b = zeros(size(train_label,1),1);
Aeq = train_label';
beq = 0;
lb = zeros(size(train_label,1),1);
ub = C.*ones(size(train_label,1),1);
x0 = [];

options = optimset('LargeScale','off','MaxIter',1000,'TolX',1e-10);
[alpha] = quadprog(H,f,A,b,Aeq,beq,lb,ub,x0,options);

Alpha_dis = alpha.*train_label;
temp = kernel_mat*Alpha_dis;
SV = find(alpha>1e-4);
b0 = train_label(SV) - temp(SV);
b0 = mean(b0);

end

