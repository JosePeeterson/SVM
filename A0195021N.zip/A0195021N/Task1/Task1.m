clc;
clear;
load 'train.mat';
load 'test.mat';

%% Input Data processing
% preprocess the training data matrix
% normalizing the sample

max_feature = max(train_data,[],2);
min_feature = min(train_data,[],2);

norm_tr_dt = (train_data - ...
   min_feature*ones(1,size(train_data,2)))./((max_feature - min_feature)*ones(1,size(train_data,2)));

%% SVM with LINEAR KERNEL and HARD MARGIN

C = 1000000;
p = 0;
[Alpha_dis,b0] = Discriminant(norm_tr_dt,train_label,'linhard',p,C);

% Calculate the training accuracy
g_tr =(norm_tr_dt'*norm_tr_dt)* Alpha_dis + b0*ones(size(norm_tr_dt,2),1);
g_tr(g_tr>=0) = 1;
g_tr(g_tr<0) = -1;
error_tr = train_label - g_tr;
disp('Hard margin & Linear Kernel Training Accuracy:');
disp(100*size(error_tr(error_tr==0),1)/size(train_label,1));

%% SVM with POLYNOMIAL KERNEL and HARD MARGIN

Alpha_dis = 0;
b0 = 0;
g_tr = 0;
g_tes = 0;

% check SVM performance for degree 2 to 5
for p = 2:5
    
    C = 1000000;
    [Alpha_dis,b0] = Discriminant(norm_tr_dt,train_label,'polyhard',p,C);

    % Calculate the training accuracy
    g_tr =(norm_tr_dt'*norm_tr_dt + ones(size(norm_tr_dt'*norm_tr_dt))).^p ...
        * Alpha_dis + b0*ones(size(norm_tr_dt,2),1);
    g_tr(g_tr>=0) = 1;
    g_tr(g_tr< 0) = -1;
    error = train_label - g_tr;
    disp('Hard Margin & Polynomial Kernel Training Accuracy:');
    disp(strcat('with p = ',num2str(p)));
    disp(100*size(error(error==0),1)/size(train_label,1));
    
end

%% SVM with POLYNOMIAL KERNEL and SOFT MARGIN

% C is cost for violating correct classification
C = [0.1 0.6 1.1 2.1];

% check SVM performance for degree 2 to 5
for p = 1:5
    for ind = 1:length(C)
        
        Alpha_dis = 0;
        b0 = 0;
        g_tr = 0;
        g_tes = 0;
        
        [Alpha_dis,b0] = Discriminant(norm_tr_dt,train_label,'polysoft',p,C(ind));
        
        % Calculate the training accuracy
        g_tr =(norm_tr_dt'*norm_tr_dt + ones(size(norm_tr_dt'*norm_tr_dt))).^p ...
            * Alpha_dis + b0*ones(size(norm_tr_dt,2),1);
        g_tr(g_tr>=0) = 1;
        g_tr(g_tr< 0) = -1;
        error = train_label - g_tr;
        disp('Soft Margin & Polynomial Kernel Training Accuracy:');
        a = strcat('with p = ',num2str(p));
        b = strcat(', C = ',num2str(C(ind),2));
        disp(strcat(a,b));
        disp(100*size(error(error==0),1)/size(train_label,1));
    end
end
