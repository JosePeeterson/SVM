Run Task3.m file
keep Discriminant.m and other .mat files in the same folder as eval.m
