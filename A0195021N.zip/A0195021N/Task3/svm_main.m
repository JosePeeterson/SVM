%
% clc
% clear
% load('eval.mat');
% load('eval_label.mat');

% SVM for eval.mat constructed using Soft margin with Polynomial Kernel
% of degree p = 4 and cost c = 2.1


%% Input Data processing
% preprocess the training data matrix
% normalizing the sample

max_feature = load('max_feature.mat');
max_feature = cell2mat(struct2cell(max_feature));
min_feature = load('min_feature.mat');
min_feature = cell2mat(struct2cell(min_feature));
norm_tr_dt = load('norm_tr_dt.mat');
norm_tr_dt = cell2mat(struct2cell(norm_tr_dt));

% norm_tr_dt = zeros(size(train_data,1),size(train_data,2));
% for i=1:size(train_data,1)
% norm_tr_dt(i,:) = (train_data(i,:) - mean(train_data(i,:)))/std(train_data(i,:));
% end

% preprocess the testing data matrix
% normalizing the sample

norm_tes_dt = (eval_data -...
min_feature*ones(1,size(eval_data,2)))./((max_feature - min_feature)*ones(1,size(eval_data,2)));

%% SVM with POLYNOMIAL KERNEL and SOFT MARGIN

% C is cost for violating correct classification
C = 2.1;
p = 4;

train_label = load('train_label.mat');
train_label = cell2mat(struct2cell(train_label));
[Alpha_dis,b0] = Discriminant(norm_tr_dt,train_label,'polysoft',p,C);


% Calculate the evaluation accuracy
eval_predicted =(norm_tes_dt'*norm_tr_dt + ones(size(norm_tes_dt'*norm_tr_dt))).^p ...
    * Alpha_dis + b0*ones(size(norm_tes_dt,2),1);
eval_predicted(eval_predicted>=0) = 1;
eval_predicted(eval_predicted< 0) = -1;

error = eval_label - eval_predicted;
disp('Soft Margin & Polynomial Kernel Testing Accuracy');
a = strcat('with p = ',num2str(p));
b = strcat(', C = ',num2str(C(1),2));
disp(strcat(a,b));
disp(100*size(error(error==0),1)/size(eval_label,1));

%% SVM with LINEAR KERNEL and HARD MARGIN
% 
% C = 1000000;
% p = 5;
% 
% train_label = load('train_label.mat');
% train_label = cell2mat(struct2cell(train_label));
% [Alpha_dis,b0] = Discriminant(norm_tr_dt,train_label,'linhard',p,C);
% 
% eval_predicted =(norm_tes_dt'*norm_tr_dt + ones(size(norm_tes_dt'*norm_tr_dt))).^p ...
%     * Alpha_dis + b0*ones(size(norm_tes_dt,2),1);
% eval_predicted(eval_predicted>=0) = 1;
% eval_predicted(eval_predicted< 0) = -1;
% error = eval_label - eval_predicted;
% disp('Hard Margin & Polynomial Kernel Testing Accuracy');
% disp(strcat('with p = ',num2str(p)));
% disp(100*size(error(error==0),1)/size(eval_label,1));
% 
